# Commission Lead Monitor

Watches a list of subreddits for posts that match commission-lead keywords
(e.g. "looking for an artist") and alerts you on Discord — fast enough
that you can usually be first to reply. It never posts, DMs, or comments
anywhere on your behalf; it only reads public Reddit feeds and sends a
message into a Discord channel/webhook **you** control. That keeps it
outside the "automated outreach" territory that gets accounts banned.

No Reddit API key, no approval wait — it uses Reddit's public `.rss`
feeds, which work without authentication.

## Setup (about 10 minutes, all free)

1. **Create a GitHub repo** (private is fine) and add these three files
   at the paths shown: `monitor.py`, `.github/workflows/monitor.yml`,
   `state.json`.

2. **Create a Discord webhook** (in your own server, not someone else's):
   - Open your Discord server → the channel you want alerts in
   - Channel settings (gear icon) → Integrations → Webhooks → New Webhook
   - Give it a name, click **Copy Webhook URL**

3. **Add the webhook URL as a GitHub secret**:
   - In your repo: Settings → Secrets and variables → Actions → New
     repository secret
   - Name: `DISCORD_WEBHOOK_URL`
   - Value: paste the URL you copied

4. **Enable Actions** on the repo if prompted (Actions tab → enable).
   The workflow runs automatically every 30 minutes. To test it
   immediately instead of waiting: Actions tab → "Commission Lead
   Monitor" → **Run workflow**.

5. Check the Discord channel — matching posts will start appearing as
   embeds with the title, a snippet, which subreddit, and a link.

## Tuning it

Open `monitor.py` and edit two lists near the top:

- `SUBREDDITS` — which subreddits to watch. Add more freely; each one
  adds a few seconds to each run, not real cost (GitHub Actions is free
  for this volume — see note below).
- `KEYWORDS` — phrases that count as a lead. Keep these specific.
  Broad single words ("art", "commission") will flood you with noise —
  phrases like "looking for an artist" are much cleaner signal.

Also replace `replace_with_your_username` in the `USER_AGENT` line with
your actual Reddit username — it's just good etiquette for identifying
your traffic, not a login.

## Costs

Free. GitHub Actions gives 2,000 free minutes/month on private repos
(unlimited on public repos); this workflow uses well under a minute per
run, so running every 30 minutes uses roughly 1,400 minutes/month —
comfortably inside the free tier.

## What to expect on the first run

The very first run has no history, so it treats every post currently in
each subreddit's "new" feed (usually the most recent ~25) as new and
checks them against your keywords. You may get a small burst of alerts
for posts that are already a few hours old — that's normal and can
actually be useful (a few live leads to start on). After that first
run, you'll only ever get alerted once per post, as it's posted.

## Honest limits

- Reddit's unauthenticated `.rss` endpoint is rate-limited per IP. The
  script already waits a few seconds between subreddits to stay under
  that; if you add many more subreddits and start seeing failures in
  the Action logs, space the schedule out to every 45–60 minutes.
- This was built and reasoned through carefully, but not live-tested
  against Reddit's servers from where it was written (network access
  was restricted there). Run it once manually (step 4 above) and check
  the Action's log output — if anything errors, send me the log and
  I'll fix it.
